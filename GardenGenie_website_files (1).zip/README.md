# GardenGenie

A Streamlit website that provides general plant-growing guidance based on a user's entered environment.

## Run locally
1. Install Python.
2. In this folder, run: `python -m pip install -r requirements.txt`
3. Run: `streamlit run app.py`

## Publish online with Streamlit Community Cloud
1. Create a GitHub account at https://github.com
2. Create a new **public** repository named `gardengenie`.
3. Upload `app.py` and `requirements.txt` to the repository.
4. Visit https://share.streamlit.io and sign in with GitHub.
5. Choose **Create app**, select your repository, branch `main`, and main file `app.py`.
6. Click **Deploy**. Streamlit will build the app and provide a public URL.

No API key is needed for this prototype. Do not put passwords or private keys in public code.
