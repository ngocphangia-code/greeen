import streamlit as st
from datetime import date

st.set_page_config(page_title="GardenGenie | Your AI Garden Companion", page_icon="🌿", layout="wide")

PLANTS = {
    "Tomato": {"emoji":"🍅","type":"Vegetable","temp":(18,30),"sun": "Full sun","water":"Keep soil evenly moist; avoid waterlogging.","soil":"Well-draining, fertile soil","days":"60–85 days","difficulty":"Medium",
        "steps":["Choose a sunny spot with at least 6–8 hours of sunlight.","Plant seedlings deeply in fertile, well-draining soil.","Add a support stake or cage as the plant grows.","Water at the base when the top layer of soil begins to dry."],
        "tips":"Tomatoes grow best in warm weather. Give each plant enough space for airflow and check leaves regularly."},
    "Basil": {"emoji":"🌱","type":"Herb","temp":(20,30),"sun":"Full sun to partial shade","water":"Water when the top 2 cm of soil feels dry.","soil":"Loose, well-draining soil","days":"3–4 weeks for established growth","difficulty":"Easy",
        "steps":["Sow seeds lightly or plant a small seedling.","Place in a warm spot with 4–6+ hours of sunlight.","Pinch the top leaves to encourage bushier growth.","Harvest a few leaves at a time; avoid removing too much."],
        "tips":"Basil likes warmth and regular harvesting. Remove flower buds if you want to encourage leaf growth."},
    "Mint": {"emoji":"🍃","type":"Herb","temp":(15,28),"sun":"Partial sun","water":"Keep soil lightly moist.","soil":"Moist, fertile soil","days":"2–3 weeks for established growth","difficulty":"Easy",
        "steps":["Choose a pot because mint spreads quickly.","Use moist, fertile potting mix.","Place where it receives morning sun or bright partial shade.","Trim stems regularly to encourage fresh growth."],
        "tips":"Mint can spread aggressively, so growing it in a container is often easiest."},
    "Lettuce": {"emoji":"🥬","type":"Vegetable","temp":(10,22),"sun":"Partial sun","water":"Water regularly; do not let soil dry out completely.","soil":"Loose, moisture-retaining soil","days":"30–60 days","difficulty":"Easy",
        "steps":["Sow seeds shallowly in a pot or garden bed.","Choose a cooler location with morning sunlight.","Keep the soil consistently moist.","Harvest outer leaves first or cut the whole plant when ready."],
        "tips":"Lettuce prefers cooler conditions. In hot weather, provide afternoon shade and watch for early flowering."},
    "Chili": {"emoji":"🌶️","type":"Vegetable","temp":(20,32),"sun":"Full sun","water":"Water deeply when the top soil starts to dry.","soil":"Fertile, well-draining soil","days":"70–100 days","difficulty":"Medium",
        "steps":["Start with seeds or a healthy seedling.","Use a pot with drainage holes and fertile soil.","Place in a warm, sunny location.","Water consistently and support the plant if it becomes heavy."],
        "tips":"Chili plants enjoy warmth and sunlight. Avoid leaving their roots in standing water."},
    "Sunflower": {"emoji":"🌻","type":"Flower","temp":(18,30),"sun":"Full sun","water":"Water deeply while young; water more during dry periods.","soil":"Well-draining soil","days":"70–100 days","difficulty":"Easy",
        "steps":["Plant seeds directly into the final pot or garden bed.","Choose a location with 6–8 hours of direct sunlight.","Water gently until seedlings become established.","Provide support for tall varieties if needed."],
        "tips":"Choose a pot large enough for the variety. Tall sunflowers may need extra support in windy areas."},
    "Marigold": {"emoji":"🌼","type":"Flower","temp":(18,30),"sun":"Full sun","water":"Water when the soil surface begins to dry.","soil":"Well-draining soil","days":"45–60 days","difficulty":"Easy",
        "steps":["Sow seeds in a small pot or directly in the garden.","Give the plant a sunny position.","Water at the base and allow excess water to drain.","Remove faded flowers to encourage more blooms."],
        "tips":"Marigolds are beginner-friendly flowers and usually tolerate warm conditions well."},
    "Aloe Vera": {"emoji":"🪴","type":"Succulent","temp":(18,30),"sun":"Bright light","water":"Let soil dry completely between waterings.","soil":"Cactus or succulent mix","days":"Slow-growing","difficulty":"Easy",
        "steps":["Choose a pot with drainage holes.","Use a gritty cactus or succulent soil mix.","Place in bright light; introduce direct sun gradually.","Water thoroughly, then wait until the soil is dry before watering again."],
        "tips":"Overwatering is a common problem for aloe vera. Make sure the pot drains freely."},
    "Lavender": {"emoji":"💜","type":"Flower","temp":(15,28),"sun":"Full sun","water":"Water sparingly once established.","soil":"Very well-draining, slightly sandy soil","days":"Several months to establish","difficulty":"Medium",
        "steps":["Choose a sunny, airy location.","Use a pot or bed with excellent drainage.","Avoid heavy, waterlogged soil.","Prune lightly after flowering to maintain shape."],
        "tips":"Lavender needs plenty of light and good drainage. Very humid conditions can make it harder to grow."}
}

st.markdown("""
<style>
.stApp {background: linear-gradient(135deg,#f5f8ef 0%,#edf4e8 55%,#f8f6ed 100%);}
.block-container {padding-top:2rem; max-width:1150px;}
.hero {background:linear-gradient(120deg,#244d36,#477b51);padding:2rem 2.2rem;border-radius:22px;color:white;margin-bottom:1.4rem;}
.hero h1 {font-size:2.7rem;margin:0;color:white;}
.hero p {font-size:1.05rem;color:#e4f0df;margin:.5rem 0 0;}
.panel {background:rgba(255,255,255,.86);padding:1.2rem 1.4rem;border:1px solid #dce8d8;border-radius:18px;}
.small-note {color:#607363;font-size:.9rem;}
div[data-testid="stMetric"] {background:white;padding:14px;border-radius:14px;border:1px solid #dce8d8;}
</style>
""", unsafe_allow_html=True)

st.markdown("""
<div class="hero">
  <div style="font-size:2rem">🌿</div>
  <h1>GardenGenie</h1>
  <p>Your personal garden companion — discover what to grow and how to help it thrive.</p>
</div>
""", unsafe_allow_html=True)

with st.sidebar:
    st.markdown("## 🌍 Your growing environment")
    country = st.text_input("Country", "Vietnam")
    region = st.text_input("Region / city", "Da Nang")
    temp = st.slider("Average temperature (°C)", 5, 40, 28)
    humidity = st.slider("Humidity (%)", 10, 100, 75)
    sunlight = st.select_slider("Daily sunlight", options=["Low (0–2 hours)","Moderate (3–5 hours)","High (6+ hours)"], value="High (6+ hours)")
    soil = st.selectbox("Soil type", ["Loamy","Sandy","Clay","Silty","Potting mix","Not sure"])
    st.caption("Tip: Use your typical growing-season conditions. These estimates are general guidance.")

left, right = st.columns([1.05, 1.55], gap="large")
with left:
    st.markdown("### 🌱 Explore plants")
    category = st.selectbox("Plant category", ["All plants","Vegetables","Herbs","Flowers","Succulents"])
    filtered = [n for n,p in PLANTS.items() if category=="All plants" or p["type"]==category[:-1] or (category=="Vegetables" and p["type"]=="Vegetable") or (category=="Succulents" and p["type"]=="Succulent")]
    selected = st.selectbox("Choose a plant", filtered)
    p = PLANTS[selected]
    st.markdown(f"""
    <div class="panel">
      <div style="font-size:3.3rem">{p['emoji']}</div>
      <h2 style="color:#284d36;margin:.2rem 0">{selected}</h2>
      <p class="small-note">{p['type']} · {p['difficulty']} to grow</p>
      <hr style="border-color:#e1eadc">
      <b>🌞 Sunlight</b><br>{p['sun']}<br><br>
      <b>🪴 Soil</b><br>{p['soil']}<br><br>
      <b>💧 Water</b><br>{p['water']}<br><br>
      <b>⏳ Typical growing time</b><br>{p['days']}
    </div>
    """, unsafe_allow_html=True)

with right:
    st.markdown("### ✨ Your personalised growing guide")
    low, high = p["temp"]
    temp_ok = low <= temp <= high
    sun_ok = (("High" in sunlight and "Full sun" in p["sun"]) or ("Moderate" in sunlight) or ("Bright light" in p["sun"] and "High" in sunlight))
    score = 50 + (25 if temp_ok else 0) + (15 if sun_ok else 0) + (10 if humidity < 85 or p["type"] != "Flower" else 0)
    score = min(score,100)
    st.progress(score/100, text=f"Estimated environment match: {score}%")
    if temp_ok:
        st.success(f"Temperature looks suitable. {selected} generally prefers {low}–{high}°C.")
    else:
        st.warning(f"Your temperature ({temp}°C) is outside the typical {low}–{high}°C range. Consider shade, seasonal timing or indoor protection.")
    if "Low" in sunlight and ("Full sun" in p["sun"] or "Bright light" in p["sun"]):
        st.info("This plant usually needs more light. Try a brighter location if possible.")
    if humidity >= 85:
        st.info("High humidity can encourage some plant diseases. Leave space between plants and avoid wetting leaves late in the day.")
    if soil in ["Clay"] and ("well-draining" in p["soil"].lower() or "drainage" in p["soil"].lower()):
        st.info("Clay soil may hold too much water. Improve drainage or use a container with suitable potting mix.")
    st.markdown("#### 🧑‍🌾 Planting steps")
    for i, step in enumerate(p["steps"],1):
        st.markdown(f"**{i}.** {step}")
    st.markdown("#### 💡 Advice for your conditions")
    st.write(p["tips"])
    st.write(f"Based on the details entered: **{region}, {country}** · {temp}°C · {humidity}% humidity · {sunlight.lower()} sunlight · {soil.lower()} soil.")

st.divider()
st.markdown("## 📅 Your weekly care checklist")
st.caption("Tick off tasks as you complete them. Your selections stay active while this page is open.")
tasks = [f"Check the soil before watering {selected.lower()}.", "Look for yellowing leaves, pests or unusual spots.", "Check that the pot or garden bed drains properly.", "Remove dead leaves and tidy the growing area.", "Review sunlight and adjust the plant's position if needed."]
cols = st.columns(2)
for i, task in enumerate(tasks):
    with cols[i%2]:
        st.checkbox(task, key=f"task_{selected}_{i}")

st.divider()
st.markdown("## 📥 Save your plant guide")
report = f"""GARDENGENIE - PERSONAL PLANT GUIDE
Plant: {selected}
Location: {region}, {country}
Temperature: {temp} C
Humidity: {humidity}%
Sunlight: {sunlight}
Soil: {soil}
Estimated environment match: {score}%

Temperature range: {low}-{high} C
Sunlight: {p['sun']}
Soil preference: {p['soil']}
Watering: {p['water']}
Growing time: {p['days']}

PLANTING STEPS
""" + "\n".join(f"{i}. {s}" for i,s in enumerate(p["steps"],1)) + f"\n\nADVICE\n{p['tips']}\n"
st.download_button("⬇️ Download my personalised plant guide", report, file_name=f"GardenGenie_{selected.replace(' ','_')}_guide.txt", mime="text/plain")
st.caption("GardenGenie is an educational prototype. Its match score and advice are estimates, not a substitute for local horticultural guidance. It does not currently use live weather data or a trained AI model.")
